
NICE MENUS 8.X
-----------------

Currently maintained by: Xiukun zhou

Originally created by: Xiukun zhou
https://www.drupal.org/u/xiukun.zhou

This module makes it easy to add dropdown and flyout menus,
using the Superfish jQuery plugin
(http://users.tpg.com.au/j_birch/plugins/superfish),
and falling back to CSS-only functionality when JS is disabled.

Please report any bugs, feature requests, etc. at:
http://drupal.org/project/issues/nice_menus.


Installation
------------
1. Copy nice_modules folder to your /modules directory.
2. At Administer -> Extend (admin/modules)
enable the module.

3. Configure the module settings at
Administer -> Configuration -> User interface -> Nice Menus (admin/config/user-interface/nice_menus).

4. Configure the Nice Menus block(s) at
Administer -> Structure -> Block layout (admin/structure/block),

Issues
------
You can track known issues at http://drupal.org/project/issues/nice_menus.


nice_menus-8.x support Upgrade included hoverIntent and superfish plugin. download plugins to:
site/all/libraries/jquery.hoverIntent/jquery.hoverIntent.js
site/all/libraries/superfish/superfish.js
